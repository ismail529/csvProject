package org.sparta.ismail.controller;

import java.io.IOException;

public class App {
    public static void main( String[] args ) throws IOException {
       Employee.readEmployees("src/main/resources/EmployeeRecords.csv");
       EmployeeThreaded.readEmployees("src/main/resources/EmployeeRecords.csv");
      // Employee.readEmployees("src/main/resources/EmployeeRecordsLarge.csv");
      // EmployeeThreaded.readEmployees("src/main/resources/EmployeeRecordsLarge.csv");
    }
}
