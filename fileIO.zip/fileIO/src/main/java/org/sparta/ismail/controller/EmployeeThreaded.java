package org.sparta.ismail.controller;

import org.sparta.ismail.model.EmployeeDAO;
import org.sparta.ismail.model.EmployeeDTO;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

public class EmployeeThreaded {

    private static  HashMap<String, EmployeeDTO> employeeRecords = new HashMap<>();
    private static  HashMap<String, EmployeeDTO> employeeRecordsfull = new HashMap<>();
    private static List<Thread> threads = new ArrayList<>();

    public static void readEmployees(String path) throws IOException {
        EmployeeDAO employeeDAO = new EmployeeDAO();
        employeeDAO.createNewTable();
        Files.deleteIfExists(Paths.get("src/main/resources/duplicateValues.csv"));
        String line;
        long startTime = System.currentTimeMillis();
        long numberOfEntries = 0;

        try (Scanner scanner = new Scanner(new File(path));
             Stream<String> stream = Files.lines(Paths.get(path))){
            numberOfEntries = stream.count();
            scanner.nextLine();
            while(scanner.hasNext()) {
                populateHashMap(scanner.nextLine());
                if (employeeRecords.size() > numberOfEntries/100 || employeeRecords.size() > 1000) {
                    Thread thread = new Thread(new InsertEmployees(employeeRecords));
                    threads.add(thread);
                    thread.start();
                    employeeRecords = new HashMap<>();
                }
            }}
           catch (IOException e) {
            e.printStackTrace();
        }
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        long timeTaken = System.currentTimeMillis() - startTime;
        System.out.println(timeTaken);
    }
    private static void populateHashMap(String line){
        String[] record = line.trim().split(",");
        EmployeeDTO employeeDTO = new EmployeeDTO(record);
            if(!employeeRecordsfull.containsKey(record[0])) {
                employeeRecords.put(record[0], employeeDTO);
                employeeRecordsfull.put(record[0], employeeDTO);
            } else{
                EmployeeFileWriter.writeEntryToFile("src/main/resources/duplicateValues.csv", employeeDTO, "duplicate");
            }
        }
}

