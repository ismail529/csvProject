package org.sparta.ismail.controller;

import org.sparta.ismail.model.EmployeeDTO;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EmployeeFileWriter {
    public static void writeEntryToFile(String filePath, EmployeeDTO employeeDTO, String type) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filePath, true));
            bufferedWriter.write(employeeDTO.toString());
            bufferedWriter.close();
        } catch (IOException e) {
            System.out.println("error not reading file");
        }
    }
}
