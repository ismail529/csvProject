package org.sparta.ismail.controller;

import org.sparta.ismail.model.EmployeeDAO;
import org.sparta.ismail.model.EmployeeDTO;

import java.util.HashMap;
    public class InsertEmployees implements Runnable {

        private HashMap<String, EmployeeDTO> employees;

        public InsertEmployees(HashMap<String, EmployeeDTO> records) {
            this.employees = records;
        }

        @Override
        public void run() {
            EmployeeDAO employeeDAO = new EmployeeDAO();
                    employeeDAO.persistToDB(employees);
        }
}
