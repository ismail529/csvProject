package org.sparta.ismail.model;

import java.sql.*;
import java.util.HashMap;

public class EmployeeDAO {
    static String db = "employees";
    private static final String URL = "jdbc:mysql://localhost:3306/" + db;
    String userName = "enter your sql name(root)";
    String password = "enter your sql password";
    private Connection connection = null;

    private static final String INSERT_STATEMENT = "INSERT INTO EmployeeRecords " +
            "VALUES(?,?,?,?,?,?,?,?,?,?)";
    private static final String DROP_TABLE = "DROP TABLE IF EXISTS EmployeeRecords";
    private static final String CREATE_TABLE = "CREATE TABLE EmployeeRecords(\n" +
            "    emp_ID INT,\n" + "    namePrefix VARCHAR(10),\n" + "    first_name VARCHAR(45),\n" +
            "    middle_initial VARCHAR(1),\n" + "    last_name VARCHAR(45),\n" + "    gender VARCHAR(1),\n" +
            "    email VARCHAR(50),\n" + "    dob DATE,\n" + "    date_of_joining DATE,\n"
            + "    salary INT,\n" + "    PRIMARY KEY (emp_ID)\n" + ")";
    private void getConnection() {
        try {
            connection = DriverManager.getConnection(URL,userName,password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void closeConnection(){
        try {
            connection.close();
        } catch (SQLException | NullPointerException throwables) {
            System.out.println(("Cannot close connection: " + throwables.getMessage()));
        }
    }

    public void createNewTable(){
        if(connection == null) getConnection();
        try {
            dropTable();
            createTable();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void persistToDB(HashMap<String, EmployeeDTO> employeeRecords) {
       if(connection == null) getConnection();
        try(PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STATEMENT)){
            int counter = 1;
            connection.setAutoCommit(false);
            for (EmployeeDTO employee : employeeRecords.values()) {
                preparedStatement.setString(1, employee.getEmp_ID());
                preparedStatement.setString(2, employee.getNamePrefix());
                preparedStatement.setString(3, employee.getFirstName());
                preparedStatement.setString(4, employee.getMiddleInitial());
                preparedStatement.setString(5, employee.getLastName());
                preparedStatement.setString(6, employee.getGender());
                preparedStatement.setString(7, employee.getEmail());
                preparedStatement.setDate(8, Date.valueOf(employee.getDob()));
                preparedStatement.setDate(9, Date.valueOf(employee.getDateOfJoining()));
                preparedStatement.setString(10, String.valueOf(employee.getSalary()));
                preparedStatement.addBatch();
                if(counter == employeeRecords.size()) {
                    int[] batchExecuted = preparedStatement.executeBatch();
                    connection.commit();
                }
                counter++;
            }
        } catch (SQLException e) {
            System.out.println(("persistToDB: " + e.getMessage()));
        }
    }

    private void dropTable() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeLargeUpdate(DROP_TABLE);
        statement.close();
    }
    private void createTable() throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeLargeUpdate(CREATE_TABLE);
        statement.close();
    }
}


