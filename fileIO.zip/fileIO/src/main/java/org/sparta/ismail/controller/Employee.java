package org.sparta.ismail.controller;

import org.sparta.ismail.model.EmployeeDAO;
import org.sparta.ismail.model.EmployeeDTO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

public class Employee {

    private static final HashMap<String, EmployeeDTO> employeeRecords = new HashMap<>();

    public static ArrayList<EmployeeDTO> readEmployees(String path) throws IOException {
        EmployeeDAO employeeDAO = new EmployeeDAO();
        employeeDAO.createNewTable();
        long startTime = System.currentTimeMillis();
        Files.deleteIfExists(Paths.get("src/main/resources/duplicateValues.csv"));
        ArrayList<EmployeeDTO> employees = new ArrayList<>();
        String line;
        try(BufferedReader bufferedReader = new BufferedReader(new FileReader(path))) {
            bufferedReader.readLine();
            while ((line = bufferedReader.readLine()) != null) {
                populateHashMap(line);
            }
            employeeDAO.persistToDB(employeeRecords);
        } catch (IOException e) {
            e.printStackTrace();
        }
        long timeTaken = System.currentTimeMillis() - startTime;
        System.out.println(timeTaken);
        return employees;
    }

    private static void populateHashMap(String line){
        String[] record = line.trim().split(",");
        EmployeeDTO employeeDTO = new EmployeeDTO(record);
            if(!employeeRecords.containsKey(record[0])) {
                employeeRecords.put(record[0], employeeDTO);
            } else{
                EmployeeFileWriter.writeEntryToFile("src/main/resources/duplicateValues.csv", employeeDTO, "duplicate");
            }
        }
}

